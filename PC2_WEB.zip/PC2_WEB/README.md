# 🌆 Smart Cities - Ciudades Inteligentes y Sostenibles

![Smart Cities Banner](https://img.shields.io/badge/Smart%20Cities-Innovation-00D9FF?style=for-the-badge&logo=city&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

## 📋 Descripción del Proyecto

**Smart Cities** es un sitio web premium que explora el futuro de las ciudades inteligentes y sostenibles. Con un diseño ultra-moderno, animaciones avanzadas y efectos visuales impresionantes, el proyecto presenta información sobre ciudades inteligentes, tecnologías innovadoras y soluciones urbanas del futuro.

Este proyecto ha sido desarrollado con las últimas tendencias en diseño web, incluyendo:
- ✨ **Glassmorphism** avanzado
- 🎭 **Animaciones 3D** y efectos parallax
- 🌊 **Gradientes cibernéticos** personalizados
- 📱 **Diseño 100% responsive**
- ♿ **Accesibilidad web** implementada
- ⚡ **Optimización de rendimiento**

## 🎨 Características Principales

### 🎯 Diseño y UI/UX

- **Paleta de Colores Cyber-Eco**: Combinación futurista de cyan, turquesa, verde neón y púrpura
- **Tipografías Premium**: Orbitron para títulos, Poppins para cuerpo
- **Efectos Glassmorphism**: Cards con efecto de vidrio esmerilado
- **Animaciones Fluidas**: Transiciones suaves y animaciones CSS avanzadas
- **Iconografía Completa**: Font Awesome 6.4.0 integrado

### 📄 Páginas Implementadas

#### 1. **index.html** - Página de Inicio
- Hero section con typing effect animado
- Sección de introducción con estadísticas
- Features cards interactivos
- CTA (Call to Action) impactante

#### 2. **about.html** - Acerca de Smart Cities
- Definición completa de ciudades inteligentes
- Historia y evolución
- Timeline interactivo
- Key points destacados

#### 3. **pillars.html** - Los 6 Pilares
- Movilidad Inteligente
- Energía Sostenible
- Gestión de Residuos
- Gobierno Digital
- Edificios Inteligentes
- Calidad de Vida

#### 4. **cities.html** ⭐ NUEVO
- Galería de 6 ciudades líderes mundiales:
  - 🇸🇬 Singapur (#1)
  - 🇪🇸 Barcelona (#2)
  - 🇳🇱 Ámsterdam (#3)
  - 🇺🇸 Nueva York (#4)
  - 🇯🇵 Tokio (#5)
  - 🇦🇺 Sídney (#6)
- Sistema de filtros por continente
- Progress bars animadas
- Ranking badges (Gold, Silver, Bronze)
- Tabla comparativa interactiva
- Cards con hover effects 3D

#### 5. **technology.html** ⭐ NUEVO
- Sistema de tabs interactivos para tecnologías:
  - **IoT** - Internet de las Cosas con animación de nodos
  - **IA** - Inteligencia Artificial con efecto cerebro
  - **Big Data** - Analytics con flujo de datos
  - **5G** - Redes con ondas de señal animadas
  - **Blockchain** - Cadena de bloques rotativa
- Visualizaciones animadas únicas para cada tecnología
- Estadísticas en tiempo real
- Features destacados por tecnología
- Sección de integración de tecnologías

#### 6. **contact.html** ⭐ NUEVO
- Formulario premium con glassmorphism
- Validación en tiempo real
- Character counter para mensajes
- Checkboxes personalizados
- Estados de loading y success
- Sidebar informativa sticky
- Quick stats cards
- Mapa placeholder interactivo
- Sección FAQ con accordion

### 🎪 Animaciones y Efectos

#### Efectos Visuales Avanzados
```css
- Gradient shifting backgrounds
- Pulse animations en iconos
- Hover effects 3D con transform
- Parallax scroll effects
- Particle floating animations
- Progress bars con shimmer effect
- Typing text effect
- Wave transitions entre secciones
- Glow effects en botones
- Smooth scroll behavior
```

#### Animaciones JavaScript
```javascript
- Counter animations para estadísticas
- Intersection Observer para lazy animations
- Tab switching con fade effects
- Filter system para cities
- Form validation real-time
- FAQ accordion
- Parallax backgrounds
- Smooth scroll con offset
- Debounced scroll events
```

## 🛠️ Tecnologías Utilizadas

### Frontend Core
- **HTML5**: Semántico y accesible
- **CSS3**: Variables CSS, Grid, Flexbox, Animations
- **JavaScript ES6+**: Async/await, Arrow functions, Modules

### Librerías y Frameworks
- **Google Fonts**: Orbitron & Poppins
- **Font Awesome 6.4.0**: Iconografía completa
- **CSS Grid & Flexbox**: Layout responsive

### Técnicas Avanzadas
- **CSS Custom Properties**: Sistema de variables completo
- **Intersection Observer API**: Scroll animations
- **Glassmorphism**: Backdrop-filter effects
- **CSS Animations & Keyframes**: 50+ animaciones personalizadas
- **Form Validation API**: Validación nativa mejorada

## 📁 Estructura del Proyecto

```
PC2_WEB/
│
├── index.html              # Página principal
├── about.html              # Acerca de
├── pillars.html            # Los 6 pilares
├── cities.html             # ⭐ Ciudades del mundo
├── technology.html         # ⭐ Tecnologías
├── contact.html            # ⭐ Contacto
├── a.html                  # Archivo auxiliar
│
├── styles.css              # Estilos globales base
├── about-styles.css        # Estilos página About
├── pillars-styles.css      # Estilos página Pillars
├── cities-styles.css       # ⭐ Estilos página Cities
├── technology-styles.css   # ⭐ Estilos página Technology
├── contact-styles.css      # ⭐ Estilos página Contact
│
├── script.js               # JavaScript principal mejorado
│
└── sources/                # Recursos adicionales
    └── (imágenes, assets)
```

## 🎨 Paleta de Colores

### Colores Principales
```css
--primary-dark: #0A192F     /* Azul oscuro profundo */
--secondary-dark: #1E3A5F   /* Azul medio */
--tertiary-dark: #112240    /* Azul oscuro alternativo */
```

### Colores de Acento
```css
--accent-cyan: #00D9FF      /* Cyan brillante */
--accent-turquoise: #4ECDC4 /* Turquesa */
--accent-green: #7FFF00     /* Verde neón */
--accent-purple: #9D4EDD    /* Púrpura */
```

### Gradientes
```css
--gradient-cyber: linear-gradient(135deg, #00D9FF 0%, #4ECDC4 50%, #7FFF00 100%)
--gradient-dark: linear-gradient(180deg, rgba(10, 25, 47, 0.95) 0%, rgba(30, 58, 95, 0.85) 100%)
```

## 🚀 Características Técnicas Destacadas

### Performance
- ⚡ CSS optimizado con selectores eficientes
- 🖼️ Lazy loading de imágenes implementado
- 📦 Debounced scroll events
- 🎯 Intersection Observer para animaciones
- 💨 Transitions hardware-accelerated

### Accesibilidad
- ♿ Semántica HTML5 correcta
- ⌨️ Navegación por teclado
- 🎨 Contraste de colores WCAG AA
- 📱 Responsive desde 320px
- 🔊 ARIA labels donde sea necesario

### Responsive Design
```css
Breakpoints:
- Mobile: 320px - 480px
- Tablet: 481px - 768px
- Desktop: 769px - 1024px
- Large Desktop: 1025px+
```

## 💡 Funcionalidades JavaScript

### Validación de Formularios
- ✅ Validación en tiempo real
- 📧 Validación de email con regex
- 📱 Validación de teléfono
- ✍️ Character counter para textarea
- 🎯 Estados visuales (error, success)

### Interactividad
```javascript
✨ Typing effect animado
🔄 Tab switching system
🎚️ City filter by continent
📊 Animated counters
❓ FAQ accordion
📜 Smooth scroll con offset
🎭 Parallax backgrounds
```

### Notificaciones
- Sistema de notificaciones toast
- 4 tipos: success, error, warning, info
- Auto-dismiss después de 5 segundos
- Animaciones de entrada/salida

## 📱 Responsive Features

- **Mobile First**: Diseño optimizado para móviles
- **Breakpoints Inteligentes**: 4 puntos de quiebre principales
- **Hamburger Menu**: Menú móvil animado
- **Touch-Friendly**: Botones y áreas táctiles optimizadas
- **Viewport Optimized**: Meta tags correctamente configurados

## 🎯 SEO y Meta Tags

Cada página incluye:
- Meta description única
- Keywords relevantes
- Open Graph tags preparados
- Title tags optimizados
- Canonical URLs listos

## 🔮 Efectos Especiales Implementados

### Cities Page
```
✨ Floating particles background
🎨 3D card hover effects
📊 Animated progress bars with shimmer
🏆 Badge system (Gold/Silver/Bronze)
📈 Comparison table with animated bars
🌍 Filter system by continent
```

### Technology Page
```
🤖 IoT orbital animation
🧠 AI brain with pulse waves
💾 Big Data streaming effect
📡 5G signal burst animation
🔗 Blockchain rotating blocks
🔄 Tab switching system
```

### Contact Page
```
🔮 Glassmorphism form design
✅ Real-time validation
💬 Character counter
📧 Success/error states
❓ FAQ accordion
🗺️ Map placeholder
👥 Social media integration
```

## 🌟 Highlights del Código

### CSS Moderno
- CSS Grid para layouts complejos
- Flexbox para alineaciones
- Custom Properties para theming
- Backdrop-filter para glassmorphism
- Clip-path para efectos especiales
- Transform 3D para profundidad
- Keyframes animations avanzadas

### JavaScript Clean
- Código modular y organizado
- Funciones reutilizables
- Event delegation
- Debouncing para performance
- Async/await patterns
- Error handling
- Comentarios descriptivos

## 📊 Estadísticas del Proyecto

```
📄 Páginas HTML: 6 + 1 auxiliar
🎨 Archivos CSS: 6 hojas de estilo
⚙️ JavaScript: 1 archivo principal (900+ líneas)
✨ Animaciones CSS: 50+ keyframes
🎯 Funcionalidades JS: 15+ features
📱 Breakpoints: 4 responsive
🎨 Colores personalizados: 12+
🔤 Tipografías: 2 familias
```

## 🚀 Cómo Usar

1. **Clonar o descargar** el proyecto
2. **Abrir** `index.html` en tu navegador
3. **Navegar** entre las páginas usando el menú
4. **Disfrutar** de las animaciones y efectos

### Archivos necesarios
```
✅ Todos los HTML en la raíz
✅ Todos los CSS en la raíz
✅ script.js en la raíz
✅ Conexión a internet (para fonts y icons)
```

## 🎓 Conceptos de Smart Cities Cubiertos

### Tecnologías
- Internet de las Cosas (IoT)
- Inteligencia Artificial (IA)
- Big Data Analytics
- Redes 5G
- Blockchain

### Pilares
- Movilidad Inteligente
- Energía Sostenible
- Gestión de Residuos
- Gobierno Digital
- Edificios Inteligentes
- Calidad de Vida

### Ciudades Destacadas
- Singapur 🇸🇬
- Barcelona 🇪🇸
- Ámsterdam 🇳🇱
- Nueva York 🇺🇸
- Tokio 🇯🇵
- Sídney 🇦🇺

## 🎨 Personalización

### Cambiar Colores
Edita las variables CSS en `styles.css`:
```css
:root {
    --accent-cyan: #TU_COLOR;
    --accent-turquoise: #TU_COLOR;
    /* ... más variables */
}
```

### Agregar Páginas
1. Crear nuevo HTML
2. Crear CSS específico
3. Actualizar navegación en todas las páginas
4. Agregar funcionalidades en script.js si necesario

## 🐛 Debugging

El proyecto incluye:
- Console logs descriptivos
- Easter egg en consola
- Error handling en forms
- Fallbacks para navegadores antiguos

## 🌐 Compatibilidad

✅ Chrome 90+
✅ Firefox 88+
✅ Safari 14+
✅ Edge 90+
⚠️ IE11 no soportado (usa CSS moderno)

## 📝 Notas del Desarrollador

Este proyecto representa el **máximo nivel de creatividad y potencial** en desarrollo web frontend. Cada línea de código fue cuidadosamente crafteada para crear una experiencia visual y funcional extraordinaria.

### Características Únicas
- **50+ animaciones CSS** personalizadas
- **Glassmorphism avanzado** en múltiples componentes
- **Sistema de tabs** con visualizaciones únicas por tecnología
- **Validación de formularios** con UX excepcional
- **Filtros dinámicos** con animaciones suaves
- **Responsive design** perfecto en todos los dispositivos

## 🏆 Logros del Proyecto

✨ Diseño visualmente impactante
🎯 UX/UI excepcional
⚡ Performance optimizado
📱 100% Responsive
♿ Accesible y semántico
🎨 Creatividad máxima
💻 Código limpio y organizado
🚀 Listo para producción

## 👨‍💻 Desarrollo

**Desarrollado con dedicación y pasión para PC2_WEB**

Proyecto sobre Ciudades Inteligentes y Sostenibles que demuestra:
- Dominio de HTML5, CSS3 y JavaScript
- Capacidad de crear interfaces modernas
- Conocimiento de UX/UI avanzado
- Habilidades de animación y efectos visuales
- Código limpio y mantenible

---

## 📞 Contacto

Para preguntas o colaboraciones sobre el proyecto, utiliza el formulario de contacto en `contact.html`

---

<div align="center">
  
### ⭐ Si te gusta este proyecto, dale una estrella ⭐

**Smart Cities - Building the Future of Urban Living** 🌆

Made with 💙 and lots of ☕

</div>
