// ============================================
// GLOBAL VARIABLES
// ============================================
const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const backToTop = document.getElementById('backToTop');
const typingText = document.getElementById('typingText');

// ============================================
// TYPING EFFECT FOR HERO
// ============================================
const words = ['Inteligente', 'Sostenible', 'Conectado', 'Innovador', 'Verde', 'Digital'];
let wordIndex = 0;
let charIndex = 0;
let isDeleting = false;
let typingSpeed = 150;

function typeEffect() {
    const currentWord = words[wordIndex];
    
    if (isDeleting) {
        typingText.textContent = currentWord.substring(0, charIndex - 1);
        charIndex--;
        typingSpeed = 100;
    } else {
        typingText.textContent = currentWord.substring(0, charIndex + 1);
        charIndex++;
        typingSpeed = 150;
    }
    
    if (!isDeleting && charIndex === currentWord.length) {
        isDeleting = true;
        typingSpeed = 2000; // Pause at end
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        wordIndex = (wordIndex + 1) % words.length;
        typingSpeed = 500; // Pause before next word
    }
    
    setTimeout(typeEffect, typingSpeed);
}

// Start typing effect when page loads
window.addEventListener('load', () => {
    setTimeout(typeEffect, 1000);
});

// ============================================
// NAVBAR SCROLL EFFECT
// ============================================
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
        backToTop.classList.add('show');
    } else {
        navbar.classList.remove('scrolled');
        backToTop.classList.remove('show');
    }
});

// ============================================
// MOBILE MENU TOGGLE
// ============================================
hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : 'auto';
});

// Close menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
    });
});

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    if (!navMenu.contains(e.target) && !hamburger.contains(e.target)) {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
});

// ============================================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        
        if (target) {
            const offsetTop = target.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// ============================================
// BACK TO TOP BUTTON
// ============================================
backToTop.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// ============================================
// SCROLL REVEAL ANIMATIONS
// ============================================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
            
            // Trigger counter animation if it's a stat card or stat box
            if (entry.target.classList.contains('stat-card') || entry.target.classList.contains('stat-box')) {
                animateCounter(entry.target);
            }
        }
    });
}, observerOptions);

// Observe all elements with fade-in classes
document.querySelectorAll('.fade-in, .fade-in-up, .fade-in-left, .fade-in-right, .reveal').forEach(el => {
    observer.observe(el);
});

// Observe all stat boxes and stat cards for counter animation
document.querySelectorAll('.stat-card, .stat-box').forEach(el => {
    observer.observe(el);
});

// ============================================
// COUNTER ANIMATION FOR STATS
// ============================================
function animateCounter(card) {
    // Try both class names for compatibility
    const numberElement = card.querySelector('.stat-number') || card.querySelector('.stat-value');
    if (!numberElement || numberElement.classList.contains('counted')) return;
    
    const target = parseFloat(numberElement.getAttribute('data-target'));
    if (isNaN(target)) return; // Safety check
    
    const duration = 2000; // 2 seconds
    const increment = target / (duration / 16); // 60fps
    let current = 0;
    
    numberElement.classList.add('counted');
    
    const updateCounter = () => {
        current += increment;
        
        if (current < target) {
            // Format number based on whether it's a decimal
            if (target % 1 !== 0) {
                numberElement.textContent = current.toFixed(1);
            } else {
                numberElement.textContent = Math.ceil(current);
            }
            requestAnimationFrame(updateCounter);
        } else {
            // Final value
            if (target % 1 !== 0) {
                numberElement.textContent = target.toFixed(1);
            } else {
                numberElement.textContent = target;
            }
        }
    };
    
    updateCounter();
}

// ============================================
// ACTIVE NAV LINK ON SCROLL
// ============================================
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= (sectionTop - 200)) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').includes(current)) {
            link.classList.add('active');
        }
    });
});

// ============================================
// NEWSLETTER FORM SUBMISSION
// ============================================
const newsletterForm = document.getElementById('newsletterForm');

if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(newsletterForm);
        const data = {
            name: formData.get('name'),
            email: formData.get('email'),
            interest: formData.get('interest')
        };
        
        // Show success message (in a real app, this would send to a server)
        showNotification('¡Gracias por suscribirte!', 'Te enviaremos las últimas novedades sobre ciudades inteligentes.', 'success');
        
        // Reset form
        newsletterForm.reset();
    });
}

// ============================================
// NOTIFICATION SYSTEM
// ============================================
function showNotification(title, message, type = 'info') {
    // Check if notification container exists, if not create it
    let notificationContainer = document.querySelector('.notification-container');
    
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.className = 'notification-container';
        document.body.appendChild(notificationContainer);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    // Icons for different types
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="fas ${icons[type] || icons.info}"></i>
        </div>
        <div class="notification-content">
            <h4 class="notification-title">${title}</h4>
            <p class="notification-message">${message}</p>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    // Add notification to container
    notificationContainer.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Add notification styles dynamically
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification-container {
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 10000;
        display: flex;
        flex-direction: column;
        gap: 1rem;
        max-width: 400px;
    }
    
    .notification {
        display: flex;
        align-items: flex-start;
        gap: 1rem;
        padding: 1.5rem;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transform: translateX(450px);
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .notification.show {
        transform: translateX(0);
        opacity: 1;
    }
    
    .notification-icon {
        font-size: 1.5rem;
        flex-shrink: 0;
    }
    
    .notification-success .notification-icon {
        color: #7FFF00;
    }
    
    .notification-error .notification-icon {
        color: #ff4757;
    }
    
    .notification-warning .notification-icon {
        color: #ffa502;
    }
    
    .notification-info .notification-icon {
        color: #00D9FF;
    }
    
    .notification-content {
        flex: 1;
    }
    
    .notification-title {
        font-size: 1rem;
        font-weight: 600;
        color: #E6F1FF;
        margin-bottom: 0.25rem;
    }
    
    .notification-message {
        font-size: 0.875rem;
        color: #8892B0;
        line-height: 1.5;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: #8892B0;
        font-size: 1rem;
        cursor: pointer;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: all 0.2s ease;
        flex-shrink: 0;
    }
    
    .notification-close:hover {
        background: rgba(255, 255, 255, 0.1);
        color: #E6F1FF;
    }
    
    @media (max-width: 768px) {
        .notification-container {
            right: 10px;
            left: 10px;
            max-width: none;
        }
        
        .notification {
            padding: 1rem;
        }
    }
`;
document.head.appendChild(notificationStyles);

// ============================================
// PARALLAX EFFECT FOR HERO BACKGROUND
// ============================================
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll('.animated-bg, .particles');
    
    parallaxElements.forEach(element => {
        const speed = 0.5;
        element.style.transform = `translateY(${scrolled * speed}px)`;
    });
});

// ============================================
// CURSOR TRAIL EFFECT (Optional - Cyber Style)
// ============================================
let cursorTrail = [];
const trailLength = 10;

document.addEventListener('mousemove', (e) => {
    // Only on desktop
    if (window.innerWidth > 768) {
        const trail = document.createElement('div');
        trail.className = 'cursor-trail';
        trail.style.left = e.pageX + 'px';
        trail.style.top = e.pageY + 'px';
        
        document.body.appendChild(trail);
        cursorTrail.push(trail);
        
        if (cursorTrail.length > trailLength) {
            const oldTrail = cursorTrail.shift();
            oldTrail.remove();
        }
        
        setTimeout(() => {
            trail.remove();
        }, 500);
    }
});

// Add cursor trail styles
const cursorStyles = document.createElement('style');
cursorStyles.textContent = `
    .cursor-trail {
        position: absolute;
        width: 5px;
        height: 5px;
        background: radial-gradient(circle, rgba(0, 217, 255, 0.8), transparent);
        border-radius: 50%;
        pointer-events: none;
        z-index: 9999;
        animation: trailFade 0.5s ease-out forwards;
    }
    
    @keyframes trailFade {
        to {
            opacity: 0;
            transform: scale(2);
        }
    }
`;
document.head.appendChild(cursorStyles);

// ============================================
// LAZY LOADING FOR IMAGES (Performance)
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    lazyImages.forEach(img => imageObserver.observe(img));
});

// ============================================
// FEATURE CARD HOVER EFFECT (3D Tilt)
// ============================================
document.querySelectorAll('.feature-card, .stat-card, .icon-box').forEach(card => {
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
    });
});

// ============================================
// PAGE LOAD ANIMATION
// ============================================
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    
    // Animate hero content
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        heroContent.style.opacity = '0';
        heroContent.style.transform = 'translateY(50px)';
        
        setTimeout(() => {
            heroContent.style.transition = 'all 1s ease';
            heroContent.style.opacity = '1';
            heroContent.style.transform = 'translateY(0)';
        }, 300);
    }
});

// ============================================
// PRELOADER (Optional)
// ============================================
function createPreloader() {
    const preloader = document.createElement('div');
    preloader.className = 'preloader';
    preloader.innerHTML = `
        <div class="preloader-content">
            <div class="preloader-logo">
                <i class="fas fa-city"></i>
            </div>
            <div class="preloader-text">Cargando...</div>
            <div class="preloader-bar">
                <div class="preloader-progress"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(preloader);
    
    window.addEventListener('load', () => {
        setTimeout(() => {
            preloader.style.opacity = '0';
            setTimeout(() => {
                preloader.remove();
            }, 500);
        }, 1000);
    });
}

// Uncomment to enable preloader
// createPreloader();

// Add preloader styles
const preloaderStyles = document.createElement('style');
preloaderStyles.textContent = `
    .preloader {
        position: fixed;
        inset: 0;
        background: #0A192F;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        transition: opacity 0.5s ease;
    }
    
    .preloader-content {
        text-align: center;
    }
    
    .preloader-logo {
        font-size: 4rem;
        background: linear-gradient(135deg, #00D9FF 0%, #4ECDC4 50%, #7FFF00 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: pulse 1.5s infinite;
        margin-bottom: 1rem;
    }
    
    .preloader-text {
        font-family: 'Orbitron', sans-serif;
        font-size: 1.25rem;
        color: #E6F1FF;
        margin-bottom: 1.5rem;
        letter-spacing: 2px;
    }
    
    .preloader-bar {
        width: 200px;
        height: 4px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 2px;
        overflow: hidden;
    }
    
    .preloader-progress {
        height: 100%;
        background: linear-gradient(90deg, #00D9FF, #4ECDC4, #7FFF00);
        animation: loading 1.5s infinite;
    }
    
    @keyframes loading {
        0% { width: 0%; }
        50% { width: 70%; }
        100% { width: 100%; }
    }
`;
document.head.appendChild(preloaderStyles);

// ============================================
// CONSOLE SIGNATURE
// ============================================
console.log(
    '%c🏙️ SmartCity Website %c Designed with ❤️ ',
    'background: linear-gradient(135deg, #00D9FF, #4ECDC4); padding: 10px 20px; color: #0A192F; font-size: 16px; font-weight: bold;',
    'background: #0A192F; padding: 10px 20px; color: #00D9FF; font-size: 14px;'
);

console.log(
    '%cWelcome to the future of cities! 🌆',
    'color: #00D9FF; font-size: 14px; font-weight: bold;'
);

// ============================================
// PERFORMANCE MONITORING (Development Only)
// ============================================
if (window.performance) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const perfData = window.performance.timing;
            const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
            console.log(`⚡ Page loaded in ${pageLoadTime}ms`);
        }, 0);
    });
}

// ============================================
// ENHANCED COUNTER ANIMATION FOR PILLARS PAGE
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    // Create observer for stat boxes specifically (pillars.html)
    const statObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const statBox = entry.target;
                const numberElement = statBox.querySelector('.stat-value');
                
                if (numberElement && !numberElement.classList.contains('counted')) {
                    animateCounter(statBox);
                }
            }
        });
    }, {
        threshold: 0.3,
        rootMargin: '0px'
    });
    
    // Observe all stat boxes (pillars.html)
    document.querySelectorAll('.stat-box').forEach(box => {
        statObserver.observe(box);
    });
    
    // Create observer for world stats (cities.html)
    const worldStatObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const worldStat = entry.target;
                const numberElement = worldStat.querySelector('.stat-number');
                
                if (numberElement && !numberElement.classList.contains('counted')) {
                    animateCounter(worldStat);
                }
            }
        });
    }, {
        threshold: 0.5,
        rootMargin: '0px'
    });
    
    // Observe all world stats (cities.html)
    document.querySelectorAll('.world-stat').forEach(stat => {
        worldStatObserver.observe(stat);
    });
    
    // Initialize new features
    initCityFilters();
    initTechnologyTabs();
    initContactForm();
    initFAQ();
    initParallax();
});

// ============================================
// CITY FILTERS FUNCTIONALITY (cities.html)
// ============================================
function initCityFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const cityCards = document.querySelectorAll('.city-card');
    
    if (filterButtons.length === 0 || cityCards.length === 0) return;
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Get filter value
            const filterValue = button.getAttribute('data-filter');
            
            // Filter cities
            cityCards.forEach(card => {
                const category = card.getAttribute('data-category');
                
                if (filterValue === 'all' || category === filterValue) {
                    card.style.display = 'flex';
                    // Retrigger animation
                    card.classList.remove('active');
                    setTimeout(() => card.classList.add('active'), 100);
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ============================================
// TECHNOLOGY TABS FUNCTIONALITY (technology.html)
// ============================================
function initTechnologyTabs() {
    const tabButtons = document.querySelectorAll('.tech-tab-btn');
    const tabContents = document.querySelectorAll('.tech-tab-content');
    
    if (tabButtons.length === 0 || tabContents.length === 0) return;
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Update active button
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Show target content
            tabContents.forEach(content => {
                const contentTab = content.getAttribute('data-content');
                if (contentTab === targetTab) {
                    content.classList.add('active');
                    
                    // Animate stat counters in this tab
                    const statNumbers = content.querySelectorAll('.stat-number');
                    statNumbers.forEach(stat => {
                        if (!stat.classList.contains('counted')) {
                            const parent = stat.closest('.tech-stat');
                            if (parent) {
                                animateCounter(parent);
                            }
                        }
                    });
                } else {
                    content.classList.remove('active');
                }
            });
        });
    });
}

// ============================================
// CONTACT FORM VALIDATION & SUBMISSION
// ============================================
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (!contactForm) return;
    
    const firstName = document.getElementById('firstName');
    const lastName = document.getElementById('lastName');
    const email = document.getElementById('email');
    const phone = document.getElementById('phone');
    const subject = document.getElementById('subject');
    const message = document.getElementById('message');
    const privacy = document.getElementById('privacy');
    const submitBtn = contactForm.querySelector('.submit-btn');
    const charCount = document.getElementById('charCount');
    
    // Character counter for message
    if (message && charCount) {
        message.addEventListener('input', () => {
            const count = message.value.length;
            charCount.textContent = count;
            
            if (count > 1000) {
                message.value = message.value.substring(0, 1000);
                charCount.textContent = '1000';
            }
        });
    }
    
    // Real-time validation
    const validateField = (field, validationFn, errorMsg) => {
        if (!field) return;
        
        field.addEventListener('blur', () => {
            const value = field.value.trim();
            const formGroup = field.closest('.form-group');
            const errorSpan = formGroup.querySelector('.form-error');
            
            if (value === '' && field.hasAttribute('required')) {
                formGroup.classList.add('error');
                formGroup.classList.remove('success');
                errorSpan.textContent = 'Este campo es requerido';
            } else if (value !== '' && !validationFn(value)) {
                formGroup.classList.add('error');
                formGroup.classList.remove('success');
                errorSpan.textContent = errorMsg;
            } else if (value !== '') {
                formGroup.classList.remove('error');
                formGroup.classList.add('success');
                errorSpan.textContent = '';
            }
        });
        
        field.addEventListener('input', () => {
            const formGroup = field.closest('.form-group');
            if (formGroup.classList.contains('error')) {
                formGroup.classList.remove('error');
                formGroup.querySelector('.form-error').textContent = '';
            }
        });
    };
    
    // Validation functions
    const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    const isValidPhone = (phone) => /^[\d\s\-\+\(\)]+$/.test(phone);
    const isValidName = (name) => name.length >= 2;
    
    // Apply validation
    validateField(firstName, isValidName, 'El nombre debe tener al menos 2 caracteres');
    validateField(lastName, isValidName, 'El apellido debe tener al menos 2 caracteres');
    validateField(email, isValidEmail, 'Ingresa un email válido');
    if (phone) validateField(phone, isValidPhone, 'Ingresa un teléfono válido');
    
    // Form submission
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Validate all required fields
        let isValid = true;
        const requiredFields = contactForm.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            const value = field.value.trim();
            const formGroup = field.closest('.form-group') || field.closest('.checkbox-group');
            const errorSpan = formGroup.querySelector('.form-error');
            
            if (field.type === 'checkbox') {
                if (!field.checked) {
                    isValid = false;
                    formGroup.classList.add('error');
                    if (errorSpan) errorSpan.textContent = 'Debes aceptar este campo';
                }
            } else if (value === '') {
                isValid = false;
                formGroup.classList.add('error');
                if (errorSpan) errorSpan.textContent = 'Este campo es requerido';
            }
        });
        
        if (!isValid) {
            showNotification('Error', 'Por favor completa todos los campos requeridos', 'error');
            return;
        }
        
        // Show loading state
        submitBtn.classList.add('loading');
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Remove loading state
        submitBtn.classList.remove('loading');
        
        // Show success message
        const successMessage = contactForm.querySelector('.form-success-message');
        if (successMessage) {
            contactForm.style.display = 'none';
            successMessage.classList.add('show');
            
            // Reset form after 3 seconds
            setTimeout(() => {
                contactForm.reset();
                contactForm.style.display = 'block';
                successMessage.classList.remove('show');
                
                // Remove all validation classes
                contactForm.querySelectorAll('.form-group').forEach(group => {
                    group.classList.remove('error', 'success');
                });
            }, 5000);
        }
        
        showNotification('¡Éxito!', 'Tu mensaje ha sido enviado correctamente', 'success');
    });
}

// ============================================
// FAQ ACCORDION FUNCTIONALITY
// ============================================
function initFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length === 0) return;
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other items
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
            });
            
            // Toggle current item
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
}

// ============================================
// PARALLAX SCROLL EFFECT
// ============================================
function initParallax() {
    const parallaxElements = document.querySelectorAll('.animated-bg, .tech-particles, .contact-particles');
    
    if (parallaxElements.length === 0) return;
    
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        
        parallaxElements.forEach(element => {
            const speed = 0.5;
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// ============================================
// SMOOTH SCROLL WITH OFFSET FOR FIXED NAVBAR
// ============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Don't prevent default for # only links
        if (href === '#' || href === '#!') return;
        
        e.preventDefault();
        
        const target = document.querySelector(href);
        
        if (target) {
            const offsetTop = target.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// ============================================
// PAGE LOAD ANIMATIONS
// ============================================
window.addEventListener('load', () => {
    // Trigger all fade-in animations
    document.querySelectorAll('.fade-in, .fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
        setTimeout(() => {
            el.classList.add('active');
        }, 100);
    });
});

// ============================================
// LAZY LOADING IMAGES
// ============================================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// ============================================
// KEYBOARD NAVIGATION ACCESSIBILITY
// ============================================
document.addEventListener('keydown', (e) => {
    // ESC key to close mobile menu
    if (e.key === 'Escape') {
        const navMenu = document.getElementById('navMenu');
        const hamburger = document.getElementById('hamburger');
        
        if (navMenu && navMenu.classList.contains('active')) {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    }
});

// ============================================
// PERFORMANCE: DEBOUNCE SCROLL EVENTS
// ============================================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounce to scroll-heavy functions
const debouncedScroll = debounce(() => {
    // Any additional scroll handlers here
}, 100);

window.addEventListener('scroll', debouncedScroll);

// ============================================
// ANIMATION ON SCROLL (Intersection Observer)
// ============================================
const animateOnScroll = () => {
    const animationObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                animationObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    // Elements to animate
    const elementsToAnimate = document.querySelectorAll('.section-header, .tech-stack-diagram, .tech-card, .layer-content, .integration-item, .timeline-item, .future-card');
    
    elementsToAnimate.forEach(el => {
        animationObserver.observe(el);
    });
};

// Initialize animations
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', animateOnScroll);
} else {
    animateOnScroll();
}

// ============================================
// CONSOLE EASTER EGG
// ============================================
console.log('%c🌆 Smart City Solutions 🌆', 'font-size: 20px; font-weight: bold; color: #00D9FF; text-shadow: 2px 2px 4px rgba(0,217,255,0.3);');
console.log('%c¿Interesado en nuestro código? ¡Únete a nuestro equipo!', 'font-size: 14px; color: #4ECDC4;');
console.log('%cVisita: https://smartcity.com/careers', 'font-size: 12px; color: #7FFF00;');

