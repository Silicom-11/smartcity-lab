// ============================================
// ENHANCED DASHBOARD FUNCTIONALITY
// ============================================

// Cities data with coordinates
const citiesData = [
    {
        name: 'Singapur',
        country: 'Singapore',
        lat: 1.3521,
        lng: 103.8198,
        population: '5.6M',
        sensors: 85000,
        co2Reduction: 42,
        rank: '#1',
        region: 'asia',
        flag: '🇸🇬',
        status: 'online',
        uptime: 99.9
    },
    {
        name: 'Barcelona',
        country: 'España',
        lat: 41.3874,
        lng: 2.1686,
        population: '5.6M',
        sensors: 45000,
        co2Reduction: 38,
        rank: '#2',
        region: 'europa',
        flag: '🇪🇸',
        status: 'online',
        uptime: 99.7
    },
    {
        name: 'Amsterdam',
        country: 'Países Bajos',
        lat: 52.3676,
        lng: 4.9041,
        population: '2.4M',
        sensors: 35000,
        co2Reduction: 45,
        rank: '#3',
        region: 'europa',
        flag: '🇳🇱',
        status: 'online',
        uptime: 99.8
    },
    {
        name: 'Nueva York',
        country: 'Estados Unidos',
        lat: 40.7128,
        lng: -74.0060,
        population: '8.3M',
        sensors: 52000,
        co2Reduction: 32,
        rank: '#4',
        region: 'america',
        flag: '🇺🇸',
        status: 'online',
        uptime: 99.6
    },
    {
        name: 'Tokio',
        country: 'Japón',
        lat: 35.6762,
        lng: 139.6503,
        population: '14M',
        sensors: 92000,
        co2Reduction: 35,
        rank: '#5',
        region: 'asia',
        flag: '🇯🇵',
        status: 'online',
        uptime: 99.9
    },
    {
        name: 'Sídney',
        country: 'Australia',
        lat: -33.8688,
        lng: 151.2093,
        population: '5.3M',
        sensors: 38000,
        co2Reduction: 40,
        rank: '#6',
        region: 'oceania',
        flag: '🇦🇺',
        status: 'online',
        uptime: 99.5
    }
];

// Initialize map
let map;
let markers = [];
let currentRegion = 'all';

function initMap() {
    // Create map centered on world
    map = L.map('worldMap', {
        zoomControl: true,
        scrollWheelZoom: true,
        minZoom: 2,
        maxZoom: 18
    }).setView([20, 0], 2);

    // Add dark theme tile layer with enhanced styling
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);

    // Add markers for each city
    citiesData.forEach((city, index) => {
        addCityMarker(city);
    });
}

function addCityMarker(city) {
    // Create custom icon
    const customIcon = L.divIcon({
        className: 'custom-marker',
        html: `
            <div class="marker-pin">
                <div class="marker-pulse"></div>
                <i class="fas fa-city"></i>
            </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 40]
    });

    // Create marker
    const marker = L.marker([city.lat, city.lng], {
        icon: customIcon,
        title: city.name
    }).addTo(map);

    // Create popup content
    const popupContent = `
        <div class="city-popup">
            <div class="popup-header">
                <span class="popup-flag">${city.flag}</span>
                <h3>${city.name}</h3>
                <span class="popup-rank">${city.rank}</span>
            </div>
            <div class="popup-stats">
                <div class="popup-stat">
                    <i class="fas fa-users"></i>
                    <span>${city.population}</span>
                </div>
                <div class="popup-stat">
                    <i class="fas fa-microchip"></i>
                    <span>${city.sensors.toLocaleString()}</span>
                </div>
                <div class="popup-stat">
                    <i class="fas fa-leaf"></i>
                    <span>${city.co2Reduction}%</span>
                </div>
            </div>
        </div>
    `;

    marker.bindPopup(popupContent, {
        className: 'custom-popup'
    });

    markers.push({ marker, city });
}

// Map controls
function initMapControls() {
    const mapButtons = document.querySelectorAll('.map-btn');
    
    mapButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            mapButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const view = btn.getAttribute('data-view');
            filterCitiesByRegion(view);
        });
    });
}

function filterCitiesByRegion(region) {
    if (region === 'all') {
        map.setView([20, 0], 2);
        markers.forEach(({ marker }) => marker.setOpacity(1));
    } else {
        markers.forEach(({ marker, city }) => {
            if (city.region === region) {
                marker.setOpacity(1);
            } else {
                marker.setOpacity(0.2);
            }
        });
        
        // Zoom to region
        const regionCities = citiesData.filter(c => c.region === region);
        if (regionCities.length > 0) {
            const bounds = L.latLngBounds(regionCities.map(c => [c.lat, c.lng]));
            map.fitBounds(bounds, { padding: [50, 50] });
        }
    }
}

// Animate stat counters
function animateStatCounters() {
    const statCards = document.querySelectorAll('.stat-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const valueElement = entry.target.querySelector('.stat-value');
                const target = parseInt(valueElement.getAttribute('data-target'));
                animateValue(valueElement, 0, target, 2000);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    statCards.forEach(card => observer.observe(card));
}

function animateValue(element, start, end, duration) {
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            element.textContent = end.toLocaleString();
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current).toLocaleString();
        }
    }, 16);
}

// Update current time
function updateTime() {
    const timeElement = document.getElementById('currentTime');
    if (timeElement) {
        setInterval(() => {
            const now = new Date();
            const time = now.toLocaleTimeString('es-ES', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            timeElement.textContent = time;
        }, 1000);
    }
}

// Initialize mini charts for each city
function initCityCharts() {
    const chartIds = ['chartSingapore', 'chartBarcelona', 'chartAmsterdam', 'chartNewYork', 'chartTokyo', 'chartSydney'];
    
    chartIds.forEach(id => {
        const canvas = document.getElementById(id);
        if (canvas) {
            createMiniChart(canvas);
        }
    });
}

function createMiniChart(canvas) {
    const ctx = canvas.getContext('2d');
    
    // Generate random data for demonstration
    const data = Array.from({ length: 7 }, () => Math.floor(Math.random() * 40) + 60);
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
            datasets: [{
                label: 'Actividad',
                data: data,
                borderColor: '#00D9FF',
                backgroundColor: 'rgba(0, 217, 255, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    display: false
                },
                y: {
                    display: false
                }
            }
        }
    });
}

// Simulate real-time data updates
function startRealTimeUpdates() {
    setInterval(() => {
        // Update sensor counts with subtle changes
        const sensorElements = document.querySelectorAll('.metric-value');
        sensorElements.forEach(el => {
            if (el.textContent.includes('K') && Math.random() > 0.7) {
                const current = parseInt(el.textContent.replace('K', ''));
                const change = Math.floor(Math.random() * 3) - 1;
                el.textContent = `${current + change}K`;
            }
        });
    }, 5000);
}

// Animate data traffic counter
function animateDataTraffic() {
    const trafficEl = document.getElementById('dataTraffic');
    if (!trafficEl) return;
    
    setInterval(() => {
        const baseValue = 1.2;
        const variation = (Math.random() * 0.4 - 0.2).toFixed(1);
        const newValue = (parseFloat(baseValue) + parseFloat(variation)).toFixed(1);
        trafficEl.textContent = `${newValue} GB/s`;
    }, 2000);
}

// Create sparkline charts for stat cards
function createSparklines() {
    const sparklineIds = ['sparklinePopulation', 'sparklineSensors', 'sparklineCO2', 'sparklineEnergy'];
    
    sparklineIds.forEach((id, index) => {
        const canvas = document.getElementById(id);
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const data = Array.from({ length: 30 }, () => Math.random() * 100);
        
        const colors = ['#00D9FF', '#7FFF00', '#4ECDC4', '#FFD700'];
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array(30).fill(''),
                datasets: [{
                    data: data,
                    borderColor: colors[index],
                    backgroundColor: `${colors[index]}20`,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                },
                scales: {
                    x: { display: false },
                    y: { display: false }
                },
                elements: {
                    line: {
                        borderWidth: 1.5
                    }
                }
            }
        });
    });
}

// Refresh stats button animation
function setupRefreshButton() {
    const btnRefresh = document.getElementById('btnRefreshStats');
    if (!btnRefresh) return;
    
    btnRefresh.addEventListener('click', () => {
        const icon = btnRefresh.querySelector('i');
        icon.style.animation = 'none';
        setTimeout(() => {
            icon.style.animation = 'rotate360 0.5s ease-in-out';
        }, 10);
        
        // Simulate refreshing stats
        setTimeout(() => {
            animateStatCounters();
        }, 500);
    });
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    // Check if we're on the dashboard page
    if (document.getElementById('worldMap')) {
        initMap();
        initMapControls();
        animateStatCounters();
        updateTime();
        initCityCharts();
        startRealTimeUpdates();
        animateDataTraffic();
        createSparklines();
        setupRefreshButton();
    }
});
