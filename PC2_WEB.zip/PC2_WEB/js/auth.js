// ============================================
// AUTHENTICATION SYSTEM - LocalStorage Based
// ============================================

// Detect if we're in root or pages folder
const isInPagesFolder = window.location.pathname.includes('/pages/');
const rootPath = isInPagesFolder ? '../' : '';
const dashboardPath = isInPagesFolder ? 'dashboard.html' : 'pages/dashboard.html';
const indexPath = isInPagesFolder ? '../index.html' : 'index.html';

// Check if user is logged in
function checkAuth() {
    const user = localStorage.getItem('smartCityUser');
    const currentPage = window.location.pathname.split('/').pop();
    
    if (!user && currentPage === 'dashboard.html') {
        window.location.href = indexPath;
    }
    
    if (user) {
        const userData = JSON.parse(user);
        updateNavbar(userData);
    }
}

// Update navbar with user info
function updateNavbar(userData) {
    const btnLogin = document.getElementById('btnLogin');
    const btnRegister = document.getElementById('btnRegister');
    const navActions = document.querySelector('.nav-actions');
    
    if (btnLogin) btnLogin.style.display = 'none';
    if (btnRegister) btnRegister.style.display = 'none';
    
    // Create user profile button if not exists
    if (navActions && !document.getElementById('userProfileBtn')) {
        const userBtn = document.createElement('button');
        userBtn.id = 'userProfileBtn';
        userBtn.className = 'btn-auth btn-profile';
        userBtn.innerHTML = `
            <i class="fas fa-user-circle"></i>
            <span>${userData.name}</span>
        `;
        navActions.appendChild(userBtn);
        
        // Create logout button
        const logoutBtn = document.createElement('button');
        logoutBtn.id = 'btnLogout';
        logoutBtn.className = 'btn-auth btn-logout';
        logoutBtn.innerHTML = `
            <i class="fas fa-sign-out-alt"></i>
            <span>Salir</span>
        `;
        logoutBtn.addEventListener('click', logout);
        navActions.appendChild(logoutBtn);
    }
}

// Login function
function login(email, password) {
    const users = JSON.parse(localStorage.getItem('smartCityUsers') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        localStorage.setItem('smartCityUser', JSON.stringify({
            name: user.name,
            email: user.email
        }));
        return { success: true, user };
    }
    
    return { success: false, message: 'Credenciales incorrectas' };
}

// Register function
function register(name, email, password) {
    const users = JSON.parse(localStorage.getItem('smartCityUsers') || '[]');
    
    if (users.find(u => u.email === email)) {
        return { success: false, message: 'El email ya está registrado' };
    }
    
    const newUser = { name, email, password };
    users.push(newUser);
    localStorage.setItem('smartCityUsers', JSON.stringify(users));
    
    localStorage.setItem('smartCityUser', JSON.stringify({
        name: newUser.name,
        email: newUser.email
    }));
    
    return { success: true, user: newUser };
}

// Logout function
function logout() {
    localStorage.removeItem('smartCityUser');
    window.location.href = indexPath;
}

// Initialize auth on page load
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    
    // Login button handler
    const btnLogin = document.getElementById('btnLogin');
    if (btnLogin) {
        btnLogin.addEventListener('click', () => {
            document.getElementById('loginModal').classList.add('active');
        });
    }
    
    // Register button handler
    const btnRegister = document.getElementById('btnRegister');
    if (btnRegister) {
        btnRegister.addEventListener('click', () => {
            document.getElementById('registerModal').classList.add('active');
        });
    }
    
    // Close modals
    const closeButtons = document.querySelectorAll('.modal-close');
    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.modal').classList.remove('active');
        });
    });
    
    // Login form submit
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            
            const result = login(email, password);
            
            if (result.success) {
                window.location.href = dashboardPath;
            } else {
                alert(result.message);
            }
        });
    }
    
    // Register form submit
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('registerName').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('registerConfirmPassword').value;
            
            if (password !== confirmPassword) {
                alert('Las contraseñas no coinciden');
                return;
            }
            
            const result = register(name, email, password);
            
            if (result.success) {
                window.location.href = dashboardPath;
            } else {
                alert(result.message);
            }
        });
    }
    
    // Switch between login and register
    const switchToRegister = document.getElementById('switchToRegister');
    if (switchToRegister) {
        switchToRegister.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('loginModal').classList.remove('active');
            document.getElementById('registerModal').classList.add('active');
        });
    }
    
    const switchToLogin = document.getElementById('switchToLogin');
    if (switchToLogin) {
        switchToLogin.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('registerModal').classList.remove('active');
            document.getElementById('loginModal').classList.add('active');
        });
    }
});
